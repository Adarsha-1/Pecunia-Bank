package com.capgemini.pecunia.util;

public enum TranscationStatus {
	Sucess,Fail;
}
