package com.capgemini.pecunia.util;

public enum ExceptionMessage {
	PAYEE_ACCOUNT_NOT_FOUND,BENIFICIARY_ACCOUNT_NOT_FOUND,INSUFFICIENT_BALANCE;
}
