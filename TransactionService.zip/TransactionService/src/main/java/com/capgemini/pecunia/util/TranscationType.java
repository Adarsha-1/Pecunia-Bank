package com.capgemini.pecunia.util;

public enum TranscationType {
	CreditByCheque,DebitBySlip,CreditBySlip,DebitByCheque,CreditByLoan;
	
}
